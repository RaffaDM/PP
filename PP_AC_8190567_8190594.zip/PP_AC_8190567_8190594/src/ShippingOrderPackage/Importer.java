/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ShippingOrderPackage;

import Boxs.Container;
import Boxs.Item;
import Boxs.Position;
import Costumers.Address;
import Costumers.Customer;
import exceptions.BoxException;
import exceptions.PositionException;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;
import order.base.IAddress;
import order.base.ICustomer;
import order.base.OrderStatus;
import order.exceptions.ContainerException;
import order.exceptions.OrderException;
import order.packing.Color;
import order.packing.IContainer;
import order.packing.IItem;
import order.packing.IPosition;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import shippingorder.IShippingOrder;

/*
* Nome: Rafael Duarte Meireles Pacheco Moreira
* Número: 8190567
* Turma: LSIRC
*
* Nome: Sérgio Manuel Monteiro Oliveira
* Número: 8190594
* Turma: LSIRC
 */
public class Importer {

    public IShippingOrder importer(String path) throws FileNotFoundException, IOException, ParseException, PositionException, BoxException, ContainerException, OrderException {
        JSONObject resultObject;
        JSONParser parser = new JSONParser();

        Reader reader = new FileReader(path);
        resultObject = (JSONObject) parser.parse(reader);

       // String orderId = (String) resultObject.get("orderId");
        JSONObject destination = (JSONObject) resultObject.get("destination");
       // IAddress destinationAdd = getAddress(destination);
       // String name = (String) resultObject.get("name");
        ICustomer costumer = getCustomer((JSONObject) resultObject.get("costumer"));
        JSONArray containers = (JSONArray) resultObject.get("containers");
        OrderStatus status = (OrderStatus) resultObject.get("status");
        IShippingOrder iso= new ShippingOrder(costumer, status);
        for(int i =0;i<containers.size();i++){
            iso.addContainer(getContainer((JSONObject)resultObject.get("containers")));
        }
        return iso;
    }

    public IAddress getAddress(JSONObject address) {
        String country = (String) address.get("country");
        int number = (int) address.get("number");
        String street = (String) address.get("stress");
        String city = (String) address.get("city");
        String state = (String) address.get("state");

        return new Address(city, country, number, state, street);
    }

    public IContainer getContainer(JSONObject container) throws PositionException, BoxException, ContainerException {
        int volume = (int) container.get("volume");
        String reference = (String) container.get("reference");
        int depth = (int) container.get("depth");
        Color color = (Color) container.get("color");
        int lenght = (int) container.get("length");
        String colorEdge = (String) container.get("colorEdge");
        int height = (int) container.get("height");
        int occupiedVolume = (int) container.get("occupiedVolume");
        IContainer containerFinal = new Container(reference, lenght, depth, height, color);
        JSONArray items = (JSONArray) container.get("items");
        for (int i = 0; i < items.size(); i++) {
            getItem((JSONObject) items.get(i));
            containerFinal.addItem(getItem((JSONObject) items.get(i)), getPosition((JSONObject) items.get(i)), getColor((JSONObject) items.get(i)));
        }
        return new Container(reference, lenght, depth, height, color);
    }

    public IItem getItem(JSONObject item) throws BoxException {
        String reference = (String) item.get("reference");
        int depth = (int) item.get("depth");
        int lenght = (int) item.get("lenght");
        String description = (String) item.get("description");
        int height = (int) item.get("height");

        return new Item(reference, description, lenght, depth, height);
    }

    public IPosition getPosition(JSONObject posicao) throws PositionException {
        int x = (int) posicao.get("x");
        int y = (int) posicao.get("y");
        int z = (int) posicao.get("z");

        return new Position(x, y, z);
    }

    public Color getColor(JSONObject color) {
        Color colorFinal = (Color) color.get("color");
        return colorFinal;
    }
 
    public ICustomer getCustomer(JSONObject customer){
        String name = (String) customer.get("name");
        int id = (int) customer.get("id");
        IAddress address = getAddress((JSONObject) customer.get("address"));
        IAddress billingAddress = getAddress((JSONObject) customer.get("billingAddress"));
        return new Customer(billingAddress, address, name);
    }
}
