/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ShippingOrderPackage;

import Boxs.Container;
import java.io.Serializable;
import order.base.ICustomer;
import order.base.IPerson;
import order.base.OrderStatus;
import exceptions.ContainerException;
import exceptions.OrderException;

import order.base.IAddress;
import order.packing.IContainer;
import shippingorder.IShippingOrder;

/*
* Nome: Rafael Duarte Meireles Pacheco Moreira
* Número: 8190567
* Turma: LSIRC
*
* Nome: Sérgio Manuel Monteiro Oliveira
* Número: 8190594
* Turma: LSIRC
 */
public class ShippingOrder implements IShippingOrder, Serializable {

    private static int nID = 1;
    private int orderId;
    private final int INC = 5;
    private int MAX_CONTAINERS = 5;
    private IContainer[] containers;
    private int nContainers;
    private ICustomer customer;
    private OrderStatus status;
    private IAddress destination;

    public ShippingOrder(ICustomer customer, OrderStatus status) {
        this.customer = customer;
        this.status = status;
        this.containers = new IContainer[MAX_CONTAINERS];
        this.nContainers = 0;
        orderId = nID++;
        destination = customer.getAddress();
    }

    /**
     * Verify is the IContainer isn't null or can't be alterated
     *
     * @param ic- IContainer to be added
     * @throws OrderException- if the container is null
     * @throws ContainerException - if the order status can't be alterated
     */
    private void watchExceptions(IContainer ic) throws OrderException, ContainerException {
        if (ic == null) {
            throw new ContainerException("Container nullException");
        }
        if (status == OrderStatus.IN_TREATMENT) {
            throw new OrderException("Order status In Treatment, can't remove");
        }
    }

    /**
     * Adds a new container to the shipping order
     *
     * @param ic -container to be added
     * @return true if the container is inserted in the shipping order. false if
     * the container already existsContainer in the shipping order
     * @throws OrderException - if the shipping order status is not equal to
     * IN_TREATMENT
     * @throws ContainerException - if: any parameter is null or the container
     * is not closed
     */
    @Override
    public boolean addContainer(IContainer ic) throws OrderException, ContainerException {

        watchExceptions(ic);

        if (existsContainer(ic) == true) {
            return false;
        }
        int i = 0;
        while (containers[i] != null) {
            if (containers[i].getReference().compareTo(ic.getReference()) == 0) {
                throw new ContainerException("Item is already on the container!");
            }
            i++;
        }
        if (nContainers == MAX_CONTAINERS) {
            MAX_CONTAINERS += INC;
            IContainer[] temp = new IContainer[nContainers];
            temp = containers;
            containers = new IContainer[MAX_CONTAINERS];
            containers = temp;
        }
        containers[nContainers++] = ic;
        return true;
    }

    /**
     * Removes a container from the shipping order
     *
     * @param ic- container to be removed
     * @return true if the container is removed in the shipping order. false if
     * the container doesn't exists in the shipping order.
     * @throws OrderException - if the status is not IN_TREATMENT
     * @throws ContainerException - if the parameter is null
     */
    @Override
    public boolean removeContainer(IContainer ic) throws OrderException, ContainerException {

        if (existsContainer(ic) == false) {
            return false;
        }
        int posicao = findContainer(ic.getReference());

        for (int i = posicao; i < nContainers - 1; i++) {
            containers[i] = containers[i + 1];
        }
        containers[--nContainers] = null;

        return true;
    }

    /**
     * Checks if the container exists in the shipping order
     *
     * @param ic - to check existence
     * @return true if the container exists in the shipping order false if the
     * container does not exists in the shipping order
     */
    @Override
    public boolean existsContainer(IContainer ic) {
        int posicao = findContainer(ic.getReference());
        if (posicao == -1) {
            return false;
        }
        return true;
    }

    /**
     * Searches for a given container based on its reference
     *
     * @param id - to find container
     * @return the index number that refers to the position occupied by the
     * container in the shipping order list
     */
    @Override
    public int findContainer(String id) {
        int posicao = -1;
        for (int i = 0; i < nContainers && posicao == -1; i++) {
            if (containers[i].getReference().equals(id) == true) {
                posicao = i;
            }
        }
        return posicao;
    }

    /**
     * Getter for destination person
     *
     * @return destination person
     */
    @Override
    public IPerson getDestination() {
        return customer;
    }

    /**
     * Setter for destination person
     *
     * @param ip - person
     */
    @Override
    public void setDestination(IPerson ip) {
        if (ip != null) {
            customer.setAddress(ip.getAddress());
            customer.setName(ip.getName());
        }
    }

    /**
     * Getter for customer who is responsabile by the shipping order
     *
     * @return customer who is responsabile by the shipping order
     */
    @Override
    public ICustomer getCustomer() {
        return customer;
    }

    /**
     * Getter for order status
     *
     * @return order status
     */
    @Override
    public OrderStatus getStatus() {
        return status;
    }

    /**
     * Setter for status. A specific order for status should be preserved: if
     * the @param status is IN_TREATMENT then the status should be:
     * AWAITS_TREATMENT if the @param status is CLOSED then the status should
     * be: IN_TREATMENT and the number of containers in the shipping order
     * should be greater than 0. Additionally, to close the shipping order, the
     * shipping order should be validated if the @param status is SHIPPED then
     * the order status should be: closed
     *
     * @param os -represents the order status to change the status
     * @throws OrderException - if the current status is not compatible with the
     * status @param status to change
     * @throws order.exceptions.ContainerException -if the volume greater than
     * the current volume (when shipping order is validated)
     * @throws order.exceptions.PositionException - if some item is outside (or
     * is overflowing) the container or if some item is overlapping with other
     * item (when shipping order is validated)
     */
    @Override
    public void setStatus(OrderStatus os) throws OrderException, order.exceptions.ContainerException, order.exceptions.PositionException {
        validate();
        this.status = os;
    }

    /**
     * Getter for shipping order unique identifier
     *
     * @return shipping order unique identifier
     */
    @Override
    public int getId() {
        return orderId;
    }

    /**
     * Returns an array (without null positions) for the containers in the
     * shipping order
     *
     * @return an array (without null positions) for the containers in the
     * shipping order
     */
    @Override
    public IContainer[] getContainers() {
        IContainer[] temp = new Container[nContainers];
        for (int i = 0; i < nContainers; i++) {
            temp[i] = containers[i];
        }
        return temp;
    }

    /**
     * Checks if any container is invalid
     *
     * @throws order.exceptions.ContainerException - if the volume greater than
     * the current volume
     * @throws order.exceptions.PositionException - if some item is outside (or
     * is overflowing) the container or if some item is overlapping with other
     * item
     */
    @Override
    public void validate() throws order.exceptions.ContainerException, order.exceptions.PositionException {
        for (int i = 0; i < nContainers; i++) {
            containers[i].validate();
        }
    }

    /**
     * Returns a string representation with a summary of the existing containers
     * and their items
     *
     * @return a string representation with a summary of the existing containers
     * and their items
     */
    @Override
    public String summary() {
        String s = "";
        for (int i = 0; i < nContainers; i++) {
            s += "\nContainer " + i + "{";
            s += containers[i].toString();

        }
        return s;
    }

    /**
     * Getter for nContainers
     *
     * @return nContianers value
     */
    public int getNContainers() {
        return nContainers;
    }

    /**
     *
     * @param obj - object to see if it's equal
     * @return true if the 2 objects are equal, false if not
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (obj instanceof ShippingOrder == false) {
            return false;
        }
        final ShippingOrder other = (ShippingOrder) obj;
        if (this.orderId != other.orderId) {
            return false;
        }

        if (this.nContainers != other.nContainers) {
            return false;
        }

        for (int i = 0; i < nContainers; i++) {
            if (this.containers[i].equals(other.containers[i]) == false) {
                return false;
            }
        }
        if (this.customer.equals(other.customer) == false) {
            return false;
        }
        if (this.status != other.status) {
            return false;
        }
        return true;
    }

    /**
     *
     * @return the convertion of the object into a String
     */
    @Override
    public String toString() {
        String s = "";
        return "\nShippingOrder{"
                + "\nId = " + orderId
                + "\nCustomer = " + customer
                + "\nStatus = " + status
                + summary() + "\n}";
    }

}
