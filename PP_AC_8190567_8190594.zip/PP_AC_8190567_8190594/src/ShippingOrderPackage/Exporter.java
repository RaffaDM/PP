/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ShippingOrderPackage;

import java.io.FileWriter;
import java.io.IOException;
import order.base.IAddress;
import order.exceptions.ContainerException;
import order.exceptions.PositionException;
import order.packing.IContainer;
import order.packing.IItemPacked;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import shippingorder.IExporter;
import shippingorder.IShippingOrder;

/*
* Nome: Rafael Duarte Meireles Pacheco Moreira
* Número: 8190567
* Turma: LSIRC
*
* Nome: Sérgio Manuel Monteiro Oliveira
* Número: 8190594
* Turma: LSIRC
 */
public class Exporter implements IExporter {

    /**
     * Serialize IShippingOrder to a specific format that can be stored
     * @param iso - to be exported
     * @throws IOException - Signals that an I/O exception of some sort has occurred. This class is the general class of exceptions produced by failed or interrupted I/O operations.
     */
    @Override
    public void export(IShippingOrder iso) throws IOException {
        try {
            iso.validate();
        } catch (ContainerException | PositionException ex) {
            throw new IOException(ex.toString());
        }
        JSONArray list = new JSONArray();

        JSONObject obj = new JSONObject();
        JSONObject obj2 = new JSONObject();
        JSONObject obj3 = new JSONObject();
        JSONObject obj4 = new JSONObject();

        obj.put("orderId", iso.getId());
        obj2.put("address",address(iso.getDestination().getAddress()));
        obj2.put("name", iso.getDestination().getName());
        obj.put("destination", obj2);
        for (IContainer container : iso.getContainers()) {
            if (container != null) {
                list.add(containers(container));
            }

        }
        obj.put("containers", list);
        obj.put("status", ""+iso.getStatus());
        
        obj3.put("address",address(iso.getCustomer().getAddress()));
        obj3.put("name", iso.getCustomer().getName());
        obj3.put("id",iso.getCustomer().getCustomerId());
        obj3.put("billingAddress",address(iso.getCustomer().getBillingAddress()));
        
        obj.put("customer", obj3);
        
        

        try (FileWriter file = new FileWriter("TesteDeFicheiro/teste.json")) {
            file.write(obj.toJSONString());
        } catch (IOException ex) {
            System.out.println(ex.toString());
        }

    }
    /**
     * Convert a IContainer to a JsonObject
     * @param container - IContainer 
     * @return a JSONObject with the container info
     */
    public JSONObject containers(IContainer container) {
        JSONObject obj = new JSONObject();
        JSONObject obj2 = new JSONObject();
        JSONArray list = new JSONArray();

        obj.put("volume", container.getVolume());
        obj.put("reference", container.getReference());
        obj.put("depth", container.getDepth());
        obj.put("color", "silver");
        obj.put("length", container.getLenght());
        obj.put("colorEdge", "silver");

        for (IItemPacked item : container.getPackedItems()) {
            if (item != null) {
                list.add(items(item));
            }
        }
        obj.put("items", list);
        obj.put("height", container.getHeight());
        obj.put("occupiedVolume", container.getOccupiedVolume());

        return obj;
    }
    
    /**
     * Convert a IItemPacked to a JsonObject
     * @param item - IItemPacked 
     * @return a JSONObject with the item info
     */
    public JSONObject items(IItemPacked item) {
        JSONObject obj = new JSONObject();

        obj.put("reference", item.getItem().getReference());
        obj.put("depth", item.getItem().getDepth());
        obj.put("color", ""+item.getColor());
        obj.put("x", item.getPosition().getX());
        obj.put("length", item.getItem().getLenght());
        obj.put("y", item.getPosition().getY());
        obj.put("description", item.getItem().getDescription());
        obj.put("z", item.getPosition().getZ());

        //ERRO AQUI
        obj.put("colorEdge", ""+item.getColor());
        obj.put("height", item.getItem().getHeight());

        return obj;
    }
    /**
     * Convert a IAddress to a JsonObject
     * @param add - IAddress 
     * @return a JSONObject with the address info
     */
    public JSONObject address(IAddress add) {
        JSONObject obj = new JSONObject();
        

        obj.put("country", add.getCountry());
        obj.put("number", add.getNumber());
        obj.put("stress", add.getStreet());
        obj.put("city", add.getCity());
        obj.put("state", add.getState());

        return obj;
    }

}
