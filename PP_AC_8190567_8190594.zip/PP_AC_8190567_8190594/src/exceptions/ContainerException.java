/*
 * Escola Superior de Tecnologia e Gestão (ESTG)
 * Politécnico do Porto (PP)
 * Licenciatura em Engenharia Informática (LEI)
 * Licenciatura em Segurança Informática em Redes de Computadores (LSIRC)
 * Paradigmas de Programação (PP)
 * 2019 / 2020
 * Class representing the exception scenarios related to Box contract instantiation and management
 *
 */
package exceptions;

/**
 *
 * @author Rafael
 */
public class ContainerException extends order.exceptions.ContainerException {
/**
 * Creates a new instance of ContainerClosedException without detail message.
 */
    public ContainerException() {
        super();
    }
/**
 * Constructs an instance of ContainerClosedException with the specified detail message.
 * @param msg - the detail message.
 */
    public ContainerException(String msg) {
    super("Ficheiro inválido pois : " + msg);
    }
}
