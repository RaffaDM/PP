/*
 * Escola Superior de Tecnologia e Gestão (ESTG)
 * Politécnico do Porto (PP)
 * Licenciatura em Engenharia Informática (LEI)
 * Licenciatura em Segurança Informática em Redes de Computadores (LSIRC)
 * Paradigmas de Programação (PP)
 * 2019 / 2020
 * Class representing the exception scenarios related to Box contract instantiation and management
 *
 */
package exceptions;

/**
 *
 * @author Rafael
 */
public class OrderException extends order.exceptions.OrderException {
/**
 * Creates a new instance of OrderException without detail message.
 */
    public OrderException() {
        super();
    }
/**
 * Constructs an instance of OrderException with the specified detail message.
 * @param msg - the detail message.
 */
    public OrderException(java.lang.String msg) {
        super(msg);
    }
}
