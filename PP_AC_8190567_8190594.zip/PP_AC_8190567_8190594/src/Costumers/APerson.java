/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Costumers;

import java.io.Serializable;
import order.base.IAddress;
import order.base.IPerson;

/*
* Nome: Rafael Duarte Meireles Pacheco Moreira
* Número: 8190567
* Turma: LSIRC
*
* Nome: Sérgio Manuel Monteiro Oliveira
* Número: 8190594
* Turma: LSIRC
 */
public abstract class APerson implements IPerson, Serializable {

    private IAddress address;
    private String name;

    public APerson(IAddress address, String name) {
        this.address = address;
        this.name = name;
    }

    /**
     * Getter for person addresss
     *
     * @return The addresss
     */
    @Override
    public IAddress getAddress() {
        return address;
    }

    /**
     * Getter for person name
     *
     * @return The person name
     */
    @Override
    public String getName() {
        return name;
    }

    /**
     * Setter for the customer addresss
     *
     * @param address - for the customer
     */
    @Override
    public void setAddress(IAddress address) {
        this.address = address;
    }

    /**
     * Setter for the person name
     *
     * @param name for the person name
     */
    @Override
    public void setName(String name) {
        this.name = name;
    }

    /**
     *
     * @param obj - object to see if it's equal
     * @return true if the 2 objects are equal, false if not
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (obj instanceof APerson == false) {
            return false;
        }
        final APerson other = (APerson) obj;
        if (this.name.equals(other.name) == false) {
            return false;
        }
        if (this.address.equals(other.address) == false) {
            return false;
        }
        return true;
    }

    /**
     *
     * @return the convertion of the object into a String
     */
    @Override
    public String toString() {
        return "\nPerson{"
                + "\nName = " + name
                + "\nAddress" + address + '}';
    }

}
