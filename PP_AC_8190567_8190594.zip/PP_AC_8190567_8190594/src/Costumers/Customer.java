package Costumers;

import java.io.Serializable;
import java.util.Objects;
import order.base.IAddress;
import order.base.ICustomer;

/*
* Nome: Rafael Duarte Meireles Pacheco Moreira
* Número: 8190567
* Turma: LSIRC
*
* Nome: Sérgio Manuel Monteiro Oliveira
* Número: 8190594
* Turma: LSIRC
 */
public class Customer extends APerson implements ICustomer, Serializable {

    private int id;
    private static int nCustomers = 1;

    private IAddress billingAddress;

    public Customer(IAddress billingAddress, IAddress address, String name) {
        super(address, name);
        this.id = nCustomers++;
        this.billingAddress = billingAddress;
    }

    /**
     * Getter for custommerId
     *
     * @return The custommerId
     */
    @Override
    public int getCustomerId() {
        return id;
    }

    /**
     * Getter for billing addresss
     *
     * @return The billing addresss
     */
    @Override
    public IAddress getBillingAddress() {
        return billingAddress;
    }

    /**
     * Setter for the billing addresss
     *
     * @param ia for the billing addresss
     */
    @Override
    public void setBillingAddress(IAddress ia) {
        this.billingAddress = ia;
    }

    /**
     *
     * @param obj - object to see if it's equal
     * @return true if the 2 objects are equal, false if not
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (super.equals(obj) == false) {
            return false;
        }
        final Customer other = (Customer) obj;

        if (!Objects.equals(this.billingAddress, other.billingAddress)) {
            return false;
        }
        return true;
    }

    /**
     *
     * @return the convertion of the object into a String
     */
    @Override
    public String toString() {
        String s = "";
        s += super.toString();
        return s
                + "\nCustomer{"
                + "\nCustomerId = " + id
                + "\nbillingAddress" + billingAddress + '}';
    }

}
