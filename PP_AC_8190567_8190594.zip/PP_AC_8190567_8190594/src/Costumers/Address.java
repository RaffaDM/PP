package Costumers;

import java.io.Serializable;
import order.base.IAddress;

/*
* Nome: Rafael Duarte Meireles Pacheco Moreira
* Número: 8190567
* Turma: LSIRC
*
* Nome: Sérgio Manuel Monteiro Oliveira
* Número: 8190594
* Turma: LSIRC
 */
public class Address implements IAddress, Serializable {

    private String city;
    private String country;
    private int number;
    private String state;
    private String stress;

    public Address(String city, String country, int number, String state, String street) {
        this.city = city;
        this.country = country;
        this.number = number;
        this.state = state;
        this.stress = street;
    }

    /**
     * Getter for city
     *
     * @return The city of the address
     */
    @Override
    public String getCity() {
        return city;
    }

    /**
     * Getter for country
     *
     * @return The country of the address
     */
    @Override
    public String getCountry() {
        return country;
    }

    /**
     * Getter for the number
     *
     * @return The number of the address
     */
    @Override
    public int getNumber() {
        return number;
    }

    /**
     * Getter for the state
     *
     * @return The state of the address
     */
    @Override
    public String getState() {
        return state;
    }

    /**
     * Getter for the street
     *
     * @return The street of the address
     */
    @Override
    public String getStreet() {
        return stress;
    }

    /**
     * Setter for the address city
     *
     * @param city - for the address
     */
    @Override
    public void setCity(String city) {
        this.city = city;
    }

    /**
     * Setter for the addres country
     * @param country - for the address
     */
    @Override
    public void setCountry(String country) {
        this.country = country;
    }

    /**
     * Setter for the address number
     *
     * @param number - for the address
     */
    @Override
    public void setNumber(int number) {
        this.number = number;
    }

    /**
     * Setter for the address state
     *
     * @param state - for the address
     */
    @Override
    public void setState(String state) {
        this.state = state;
    }

    /**
     * Setter for the address street
     *
     * @param street - for the address
     */
    @Override
    public void setStreet(String street) {
        this.stress = street;
    }

    /**
     *
     * @param obj - object to see if it's equal
     * @return true if the 2 objects are equal, false if not
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        final Address other = (Address) obj;
        if (this.number != other.number) {
            return false;
        }
        if (this.city.equals(other.city) == false) {
            return false;
        }
        if (this.country.equals(other.country) == false) {
            return false;
        }
        if (this.state.equals(other.state) == false) {
            return false;
        }
        if (this.stress.equals(other.stress) == false) {
            return false;
        }
        return true;
    }

    /**
     *
     * @return the convertion of the object into a String
     */
    @Override
    public String toString() {
        return "{"
                + "\nCity = " + city
                + "\nCountry = " + country
                + "\nNumber = " + number
                + "\nState = " + state
                + "\nStreet = " + stress + '}';
    }

}
