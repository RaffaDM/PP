/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Main;

import Boxs.*;
import Costumers.Address;
import Costumers.Customer;
import ShippingOrderPackage.Exporter;
import ShippingOrderPackage.Importer;
import ShippingOrderPackage.ShippingOrder;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import order.base.IAddress;
import order.base.ICustomer;
import order.base.OrderStatus;
import exceptions.BoxException;
import exceptions.ContainerException;
import exceptions.OrderException;
import exceptions.PositionException;
import java.util.Scanner;
import order.packing.*;
import org.json.simple.parser.ParseException;
import packing_gui.PackingGUI;
import shippingorder.IExporter;
import shippingorder.IShippingOrder;

/**
 *
 * @author Rafael
 */
public class Demo {

    /*
    * Nome: Rafael Duarte Meireles Pacheco Moreira
    * Número: 8190567
    * Turma: LSIRC
    *
    * Nome: Sérgio Manuel Monteiro Oliveira
    * Número: 8190594
    * Turma: LSIRC
    */

    public static void main(String[] args) {
    
        try {
            IPosition position = new Position(5, 4, 4);
            IPosition position2 = new Position(5, 4, 0);
            IPosition position3 = new Position(20, 0, 0);
            IItem i1 = new Item("ITEM1", "ITEM1", 1, 1, 1);
            IItem i2 = new Item("ITEM2", "ITEM1", 2, 2, 2);
            IItem i3 = new Item("ITEM3", "ITEM1", 10, 10, 10);
            IContainer c1 = new Container("c1", 50, 50, 50, Color.white);
            IContainer c2 = new Container("c2", 50, 100, 50, Color.white);
            c1.addItem(i1, position, Color.aqua);
            c1.addItem(i2, position2, Color.blue);
            c1.addItem(i3, position3, Color.gray);
            c2.addItem(i1, position, Color.aqua);
            c2.addItem(i2, position2, Color.blue);
            c2.addItem(i3, position3, Color.gray);
            IAddress address = new Address("city A2", "country A2", 2, "state A2", "street A2");
            ICustomer customer = new Customer(address, address, "Jane Doe");
            IShippingOrder shipping = new ShippingOrder(customer, OrderStatus.RECEIVED);
            System.out.println(shipping.addContainer(c1));
            System.out.println(shipping.toString());
            shipping.addContainer(c2);
            IExporter exporter = new Exporter();
            exporter.export(shipping);
            PackingGUI.render("TesteDeFicheiro/teste.json");
        } catch (order.exceptions.BoxException | order.exceptions.PositionException | order.exceptions.OrderException | BoxException | order.exceptions.ContainerException | IOException | ParseException ex) {
            System.out.println(ex.toString());
        }
        
        
    }
}
