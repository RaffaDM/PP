/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Boxs;

import exceptions.PositionException;
import java.io.Serializable;
import order.packing.IPosition;

/*
* Nome: Rafael Duarte Meireles Pacheco Moreira
* Número: 8190567
* Turma: LSIRC
*
* Nome: Sérgio Manuel Monteiro Oliveira
* Número: 8190594
* Turma: LSIRC
 */
public class Position implements IPosition, Serializable {

    private int x;
    private int y;
    private int z;

    public Position(int x, int y, int z) throws exceptions.PositionException {
        if (x < 0 || y < 0 || z < 0) {
            throw new exceptions.PositionException("Invalid positions!");
        }
        this.x = x;
        this.y = y;
        this.z = z;
    }

    /**
     * Getter for x coordinate
     *
     * @return x coordinate
     */
    @Override
    public int getX() {
        return x;
    }

    /**
     * Getter for y coordinate
     *
     * @return y coordinate
     */
    @Override
    public int getY() {
        return y;
    }

    /**
     * Getter for z coordinate
     *
     * @return z coordinate
     */
    @Override
    public int getZ() {
        return z;
    }

    /**
     * Setter for x coordinate
     *
     * @param x coordinate value
     * @throws exceptions.PositionException if x coordinate is lower than 0
     */
    @Override
    public void setX(int x) throws exceptions.PositionException {
        if (x < 0) {
            throw new exceptions.PositionException("Invalid X!");
        }
        this.x = x;
    }

    /**
     * Setter for y coordinate
     *
     * @param y coordinate value
     * @throws exceptions.PositionException if y coordinate is lower than 0
     */
    @Override
    public void setY(int y) throws exceptions.PositionException {
        if (y < 0) {
            throw new exceptions.PositionException("Invalid Y!");
        }
        this.y = y;
    }

    /**
     * Setter for z coordinate
     *
     * @param z coordinate value
     * @throws exceptions.PositionException if z coordinate is lower than 0
     */
    @Override
    public void setZ(int z) throws exceptions.PositionException {
        if (z < 0) {
            throw new exceptions.PositionException("Invalid X!");
        }
        this.z = z;
    }

    /**
     *
     * @param obj - object to see if it's equal
     * @return true if the 2 objects are equal, false if not
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (obj instanceof Position == false) {
            return false;
        }
        final Position other = (Position) obj;
        if (this.x != other.x) {
            return false;
        }
        if (this.y != other.y) {
            return false;
        }
        if (this.z != other.z) {
            return false;
        }
        return true;
    }

    /**
     *
     * @return the convertion of the object into a String
     */
    @Override
    public String toString() {
        return "Position{" + "x=" + x + ", y=" + y + ", z=" + z + '}';
    }

}
