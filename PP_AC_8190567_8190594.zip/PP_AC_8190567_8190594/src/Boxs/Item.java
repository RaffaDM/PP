/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Boxs;

import exceptions.BoxException;
import java.io.Serializable;
import order.packing.IItem;

/*
* Nome: Rafael Duarte Meireles Pacheco Moreira
* Número: 8190567
* Turma: LSIRC
*
* Nome: Sérgio Manuel Monteiro Oliveira
* Número: 8190594
* Turma: LSIRC
*/
public class Item extends Box implements IItem,Serializable {

    private String reference;
    private String description;

    public Item(String reference, String description, int lenght, int depth, int height ) throws BoxException {
        super(lenght, depth,height );
        this.reference = reference;
        this.description = description;
    }
    /**
     * Getter for item reference that acts as unique identifier for the item
     * @return item reference
     */
    @Override
    public String getReference() {
        return reference;
    }
    /**
     * Getter for item description
     * @return item description
     */
    @Override
    public String getDescription() {
        return description;
    }
    /**
     * Setter for the item description
     * @param string - description - a textual description for the item 
     */
    @Override
    public void setDescription(String string) {
        description = string;
    }
    
    /**
 * 
 * @param obj - object to see if it's equal
 * @return true if the 2 objects are equal, false if not
 */
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (obj instanceof Item == false) {
            return false;
        }
        if(super.equals(obj)==false){
            return false;
        }
        final Item other = (Item) obj;
        if (this.reference.equals(other.reference) == false) {
            return false;
        }
        if (this.description.equals(other.description) == false) {
            return false;
        }
        return true;
    }

/**
 * 
 * @return the convertion of the object into a String
 */
    @Override
    public String toString() {
        String s = "";
        s += super.toString();
        return s
                + "\n\t\t   Reference = " + reference
                + "\n\t\t   Description = " + description + "\n \t\t}";
    }

}
