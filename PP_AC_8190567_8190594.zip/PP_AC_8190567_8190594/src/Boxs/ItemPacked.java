/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Boxs;

import java.io.Serializable;
import javax.swing.text.Position;
import order.packing.Color;
import order.packing.IItem;
import order.packing.IItemPacked;
import order.packing.IPosition;

/*
* Nome: Rafael Duarte Meireles Pacheco Moreira
* Número: 8190567
* Turma: LSIRC
*
* Nome: Sérgio Manuel Monteiro Oliveira
* Número: 8190594
* Turma: LSIRC
*/
public class ItemPacked implements IItemPacked,Serializable {

    private IItem item;
    private Color color;
    private IPosition position;
    private Color colorEdge;

    public ItemPacked(IItem item, Color color, IPosition position) {
        this.item = item;
        this.color = color;
        this.position = position;
        this.colorEdge= color;
    }
    /**
     * Getter for IItemPacked color
     * @return IItemPacked color
     */
    @Override
    public Color getColor() {
        return color;
    }
    /**
     * Getter for the IItem packing configuration
     * @return IItem packing configuration
     */
    @Override
    public IItem getItem() {
        return item;
    }
    /**
     * Getter for the packing IPosition
     * @return packing IPosition
     */
    @Override
    public IPosition getPosition() {
        return position;
    }
    /**
     * Setter for the IItemPacked color
     * @param color - for the IItemPacked
     */
    @Override
    public void setColor(Color color) {
        this.color = color;
    }
    /**
     * Setter of the IItemPacked position
     * @param ip - packing IPosition

     */
    @Override
    public void setPosition(IPosition ip) {
        position = ip;
    }
    public int getFinalX(){
        return (item.getLenght()+position.getX());
    }
    public int getFinalY(){ 
        return (item.getDepth()+position.getY());
    }
    public int getFinalZ(){
        
        return (item.getHeight()+position.getZ());
    }
    /**
     *
     * @param obj - object to see if it's equal
     * @return true if the 2 objects are equal, false if not
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (obj instanceof ItemPacked == false) {
            return false;
        }
        final ItemPacked other = (ItemPacked) obj;
        if (this.item.equals(other.item) == false) {
            return false;
        }
        if (this.color != other.color) {
            return false;
        }
        if (this.position.equals(other.position) == false) {
            return false;
        }
        return true;
    }
    /**
     * 
     * @return the convertion of the object into a String
     */
    @Override
    public String toString() {

        return "\n\tItemPacked{"
                + "\n\t\tItem {" + item
                + "\n\t\tColor = " + color
                + "\n\t\tPosition = " + position + "\n\t}";
    }

}
