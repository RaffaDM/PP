/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Boxs;

import exceptions.BoxException;
import java.io.Serializable;
import order.packing.IBox;

/*
* Nome: Rafael Duarte Meireles Pacheco Moreira
* Número: 8190567
* Turma: LSIRC
*
* Nome: Sérgio Manuel Monteiro Oliveira
* Número: 8190594
* Turma: LSIRC
*/
public abstract class Box implements IBox,Serializable {

    private int depth;
    private int height;
    private int lenght;

    public Box(int lenght, int depth, int height) throws BoxException {
        if (depth < 0 || height < 0 || lenght < 0) {
            throw new BoxException("Invalid Sizes!!");
        }
        this.depth = depth;
        this.height = height;
        this.lenght = lenght;
    }
    
    /**
     * Getter of depth
     * @return the depth value
     */
    @Override
    public int getDepth() {
        return depth;
    }
    /**
     * Getter of height
     *
     * @return the height value
    */
    @Override
    public int getHeight() {
        return height;
    }
    /**
     * Getter of Lenght
     *
     * @return the Lenght value
    */
    @Override
    public int getLenght() {
        return lenght;
    }
 /**
     * Getter of Volume
     *
     * @return the Volume value
    */
    @Override
    public int getVolume() {
        return (depth * height * lenght);
    }
/**
 * 
 * @param obj - object to see if it's equal
 * @return true if the 2 objects are equal, false if not
 */
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (obj instanceof Box == false) {
            return false;
        }
        final Box other = (Box) obj;
        if (this.depth != other.depth) {
            return false;
        }
        if (this.height != other.height) {
            return false;
        }
        if (this.lenght != other.lenght) {
            return false;
        }
        return true;
    }
/**
 * 
 * @return the convertion of the object into a String
 */
    @Override
    public String toString() {
        return "Box{" + 
                "depth = " + depth + 
                ", height = " + height + 
                ", lenght = " + lenght + 
                '}';
    }

       

   
    

}
