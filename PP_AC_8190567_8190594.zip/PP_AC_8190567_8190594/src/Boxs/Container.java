/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Boxs;

import exceptions.BoxException;
import exceptions.ContainerException;
import exceptions.PositionException;
import java.io.Serializable;
import order.packing.Color;
import order.packing.IContainer;
import order.packing.IItem;
import order.packing.IItemPacked;
import order.packing.IPosition;

/*
* Nome: Rafael Duarte Meireles Pacheco Moreira
* Número: 8190567
* Turma: LSIRC
*
* Nome: Sérgio Manuel Monteiro Oliveira
* Número: 8190594
* Turma: LSIRC
 */
public class Container extends Box implements IContainer, Serializable {

    private Color color;
    private Color colorEdge;
    private int volume;
    private int occupiedVolume;
    private final int INC = 5;
    private int MAX_ITEMS = 5;
    private IItemPacked[] items;
    private int nItems;
    private String reference;
    private boolean close;

    public Container(String reference, int lenght, int depth, int height, Color color) throws BoxException {
        super(lenght, depth, height);
        items = new ItemPacked[MAX_ITEMS];
        this.reference = reference;
        nItems = 0;
        this.color = color;
        this.colorEdge = color;
        volume = lenght * depth * height;
        close = false;
        occupiedVolume = 0;
    }
    /**
     * Verify if the item isnt null and if the container is closed
     * @param item receive an item
     * @throws exceptions.ContainerException 
     */
    private void watchExceptions(IItem item) throws exceptions.ContainerException {
        if (item == null) {
            throw new ContainerException("Container nullException");
        }
        if (isClosed() == true) {
            throw new ContainerException("Container is closed!");
        }
    }

    /**
     * Adds a new IItemPacked to the container considering the given item, position and color
     * @param iitem - item to be added
     * @param ip - position in which the item will be placed
     * @param color - color used for the item
     * @return  true if the item is inserted in the container. When the item is inserted, the volume should be updated. If there isn't enough space in the collection, the collection should be adjusted to store more items false if the item already exists in the container
     * @throws exceptions.ContainerException - if: any parameter is null or the container is closed
     */
    @Override
    public boolean addItem(IItem iitem, IPosition ip, Color color) throws exceptions.ContainerException {
        watchExceptions(iitem);

        if (ip == null || color == null) {
            throw new exceptions.ContainerException("Some parameter is null!");
        }

        int i = 0;
        while (items[i] != null) {
            if (items[i].getItem().getReference().compareTo(iitem.getReference()) == 0) {
                throw new exceptions.ContainerException("Item is already on the container!");
            }
            i++;
        }
        if (nItems == MAX_ITEMS) {
            MAX_ITEMS += INC;
            IItemPacked[] temp = new IItemPacked[nItems];
            temp = items;
            items = new IItemPacked[MAX_ITEMS];
            items = temp;
        }
        items[nItems++] = new ItemPacked(iitem, color, ip);
        occupiedVolume += iitem.getVolume();
        return true;
    }

    /**
     * Removes an item from the container
     * @param iitem - item to be removed
     * @return true if the item is removed in the container. When the item is removed, the volume should be updated. false if the item doesn't exists in the container
     * @throws exceptions.ContainerException if: the parameter is null or the container is closed
     */
    @Override
    public boolean removeItem(IItem iitem) throws exceptions.ContainerException {
        watchExceptions(iitem);

        int posicao = -1;
        for (int i = 0; i < nItems && posicao != -1; i++) {
            if (items[i].equals(iitem) == true) {
                posicao = i;
            }
        }
        if (posicao == -1) {
            throw new exceptions.ContainerException("Item doesn't exists on the cointainer!");
        }
        occupiedVolume -= items[posicao].getItem().getVolume();
        for (int i = posicao; i < nItems - 1; i++) {
            items[i] = items[i + 1];
        }
        items[--nItems] = null;
        return true;

    }

    /**
     * Validates the container structure considering: 
     *  if the volume if lesser or equal to the current volume.
     *  if all items are inside the container.
     *  if non of the items inside the container are overlapping
     * @throws ContainerException - if the volume greater than the current volume.
     * PositionException - if some item is outside (or is overflowing) the container or if some item is overlapping with other item.
     */
    @Override
    public void validate() throws exceptions.ContainerException, exceptions.PositionException {
        if (getOccupiedVolume() > super.getVolume()) {
            throw new exceptions.ContainerException("Container Volume exceeded!");
        }
        for (int i = 0; i < nItems; i++) {
            try {
                validateItem(items[i]);
            } catch (exceptions.PositionException ex) {
                throw new exceptions.PositionException(ex.toString());
            }
        }
        for (int i = 0; i < nItems; i++) {
            for (int j = i + 1; j < nItems; j++) {
                validateBetweenItems(items[i], items[j]);
            }
        }

    }
    /**
     * Validate if the cordinate(A) receive is inside of the other(B).
     * @param inicialA - start of the cordinate A
     * @param finalA - start of the cordinate A + the box size
     * @param inicialB -start of the cordinate B
     * @param finalB -start of the cordinate B + the box size
     * @return true if the cordinate A isnt inside of other(B)false if it is
     */
    private boolean validateCordinate(int inicialA, int finalA, int inicialB, int finalB) {
        if (inicialA <= inicialB && finalA >= inicialB) {
            return false;

        } else if (inicialA<= finalB && finalA >= finalB) {
            return false;
        }
        return true;
    }
    /**
     * Verify if 2 items don't collide
     * @param itemA - first item
     * @param itemB - second item
     * @throws exceptions.PositionException if they collide 
     */
    private void validateBetweenItems(IItemPacked itemA, IItemPacked itemB) throws exceptions.PositionException {
        if (validateCordinate(itemA.getPosition().getX(), (itemA.getPosition().getX() + itemA.getItem().getLenght()), itemB.getPosition().getX(), (itemB.getPosition().getX() + itemB.getItem().getLenght())) == false) {
            if (validateCordinate(itemA.getPosition().getY(), (itemA.getPosition().getY() + itemA.getItem().getDepth()),
                    itemB.getPosition().getY(), (itemB.getPosition().getY() + itemB.getItem().getDepth())) == false) {
                if (validateCordinate(itemA.getPosition().getZ(), (itemA.getPosition().getZ() + itemA.getItem().getHeight()),
                        itemB.getPosition().getZ(), (itemB.getPosition().getZ() + itemB.getItem().getHeight())) == false) {
                    throw new exceptions.PositionException("Box inside of a Box!!");
                }
            }
        }
    }
    /**
     * Verify if the item received is inside of the container
     * @param item -item received
     * @throws exceptions.PositionException if the item is outside of the container
     */
    private void validateItem(IItemPacked item) throws exceptions.PositionException {
        if (item.getPosition().getX() < 0 || item.getPosition().getX() > super.getLenght()) {
            throw new exceptions.PositionException("The coordinate X out of the container!");
        }
        if ((item.getPosition().getX() + item.getItem().getLenght()) < 0 || (item.getPosition().getX() + item.getItem().getLenght()) > super.getLenght()) {
            throw new exceptions.PositionException("The coordinate X out of the container!");
        }
        if (item.getPosition().getY() < 0 || item.getPosition().getY() > super.getDepth()) {
            throw new exceptions.PositionException("The coordinate Y out of the container!");
        }
        if ((item.getPosition().getY() + item.getItem().getDepth()) < 0 || (item.getPosition().getY() + item.getItem().getDepth()) > super.getDepth()) {
            throw new exceptions.PositionException("The coordinate Y out of the container!");
        }
        if (item.getPosition().getZ() < 0 || item.getPosition().getZ() > super.getHeight()) {
            throw new exceptions.PositionException("The coordinate Z out of the container!");
        }
        if ((item.getPosition().getZ() + item.getItem().getHeight()) < 0 || (item.getPosition().getZ() + item.getItem().getHeight()) > super.getHeight()) {
            throw new exceptions.PositionException("The coordinate Z out of the container!");
        }
    }

    /**
     * Close the container. Before closing the container, a validation procedure is performed.
     * @throws exceptions.ContainerException - if the volume greater than the current volume
     * @throws exceptions.PositionException - if some item is outside (or is overflowing) the container or if some item is overlapping with other item
     */
    @Override
    public void close() throws exceptions.ContainerException, exceptions.PositionException {
        try {
            validate();
        } catch (ContainerException ex) {
            throw new exceptions.ContainerException(ex.toString());
        } catch (PositionException ex) {
            throw new exceptions.PositionException(ex.toString());
        }
        close = true;
    }

    /**
     * Returns the item with a given reference
     * @param reference - (unique identifier) of the item
     * @return item with a given reference
     */
    @Override
    public IItem getItem(String reference) {
        for (int i = 0; i < nItems; i++) {
            if (reference.equals(items[i].getItem().getReference()) == true) {
                return items[i].getItem();
            }
        }
        return null;
    }

    /**
     * Return the occupied volume in the container
     * @return occupied volume in the container
     */
    @Override
    public int getOccupiedVolume() {
        return occupiedVolume;
    }

    /**
     * Returns an array (without null positions) for the items packed in the container
     * @return the items packed in the container
     */
    @Override
    public IItemPacked[] getPackedItems() {
        IItemPacked[] temp = new IItemPacked[nItems];
        int i = 0;
        while (i < nItems) {
            temp[i] = items[i];
            i++;
        }
        return temp;
    }

    /**
     * Getter for container reference that acts as unique identifier for the container
     * @return container reference
     */
    @Override
    public String getReference() {
        return reference;
    }

    /**
     * Returns the number of items in the container
     * @return number of items in the container
     */
    @Override
    public int getNumberOfItems() {
        return nItems;
    }

    /**
     * Return the remaining volume in the container
     * @return remaining volume in the container
     */
    @Override
    public int getRemainingVolume() {
        return (volume - getOccupiedVolume());
    }

    /**
     * Return if the container is closed
     * @return true if the container is closed, false if the container is not closed
     */
    @Override
    public boolean isClosed() {
        return close;
    }

/**
 * 
 * @param obj - object to see if it's equal
 * @return true if the 2 objects are equal, false if not
 */
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Container other = (Container) obj;
        if (this.MAX_ITEMS != other.MAX_ITEMS) {
            return false;
        }
        if (this.nItems != other.nItems) {
            return false;
        }
        if (this.close != other.close) {
            return false;
        }
        if (this.reference.equals(other.reference) == false) {
            return false;
        }
        for (int i = 0; i < nItems; i++) {
            if (this.items[i].equals(other.items[i]) == false) {
                return false;
            }
        }
        return true;
    }
    
    /**
     * 
     * @return the convertion of the object into a String
     */
    @Override
    public String toString() {
        String s = "";

        for (int i = 0; i < nItems; i++) {
            s += "\n" + items[i].toString();
        }
        return "\n\tReference:" + reference
                + "\n\tClose:" + close
                + s + "\n     }";

    }

}
